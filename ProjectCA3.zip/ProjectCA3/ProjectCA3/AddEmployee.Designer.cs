﻿namespace ProjectCA3
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.idNo = new System.Windows.Forms.Label();
            this.txtIdNo = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.contact = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.designation = new System.Windows.Forms.Label();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.department = new System.Windows.Forms.Label();
            this.wage = new System.Windows.Forms.Label();
            this.txtWage = new System.Windows.Forms.TextBox();
            this.workedHour = new System.Windows.Forms.Label();
            this.txtWorkedHour = new System.Windows.Forms.TextBox();
            this.joinedDate = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.comboBoxDepartment = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // idNo
            // 
            this.idNo.AutoSize = true;
            this.idNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idNo.Location = new System.Drawing.Point(33, 18);
            this.idNo.Name = "idNo";
            this.idNo.Size = new System.Drawing.Size(79, 29);
            this.idNo.TabIndex = 0;
            this.idNo.Text = "ID NO";
            // 
            // txtIdNo
            // 
            this.txtIdNo.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtIdNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIdNo.Enabled = false;
            this.txtIdNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdNo.Location = new System.Drawing.Point(38, 65);
            this.txtIdNo.Name = "txtIdNo";
            this.txtIdNo.Size = new System.Drawing.Size(254, 35);
            this.txtIdNo.TabIndex = 1;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(367, 18);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(124, 29);
            this.name.TabIndex = 0;
            this.name.Text = "Full Name";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(372, 65);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(254, 35);
            this.txtName.TabIndex = 1;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.Location = new System.Drawing.Point(709, 18);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(102, 29);
            this.address.TabIndex = 0;
            this.address.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(714, 65);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(254, 35);
            this.txtAddress.TabIndex = 1;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            // 
            // contact
            // 
            this.contact.AutoSize = true;
            this.contact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.Location = new System.Drawing.Point(33, 143);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(94, 29);
            this.contact.TabIndex = 0;
            this.contact.Text = "Contact";
            // 
            // txtContact
            // 
            this.txtContact.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(38, 190);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(254, 35);
            this.txtContact.TabIndex = 1;
            this.txtContact.TextChanged += new System.EventHandler(this.txtContact_TextChanged);
            this.txtContact.Leave += new System.EventHandler(this.txtContact_Leave);
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.Location = new System.Drawing.Point(367, 143);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(74, 29);
            this.email.TabIndex = 0;
            this.email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(372, 190);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(254, 35);
            this.txtEmail.TabIndex = 1;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // designation
            // 
            this.designation.AutoSize = true;
            this.designation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.designation.Location = new System.Drawing.Point(709, 143);
            this.designation.Name = "designation";
            this.designation.Size = new System.Drawing.Size(141, 29);
            this.designation.TabIndex = 0;
            this.designation.Text = "Designation";
            // 
            // txtDesignation
            // 
            this.txtDesignation.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtDesignation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesignation.Location = new System.Drawing.Point(714, 190);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(254, 35);
            this.txtDesignation.TabIndex = 1;
            this.txtDesignation.TextChanged += new System.EventHandler(this.txtDesignation_TextChanged);
            // 
            // department
            // 
            this.department.AutoSize = true;
            this.department.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.department.Location = new System.Drawing.Point(33, 286);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(138, 29);
            this.department.TabIndex = 0;
            this.department.Text = "Department";
            // 
            // wage
            // 
            this.wage.AutoSize = true;
            this.wage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wage.Location = new System.Drawing.Point(367, 286);
            this.wage.Name = "wage";
            this.wage.Size = new System.Drawing.Size(132, 29);
            this.wage.TabIndex = 0;
            this.wage.Text = "Wage Rate";
            // 
            // txtWage
            // 
            this.txtWage.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtWage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWage.Location = new System.Drawing.Point(372, 333);
            this.txtWage.Name = "txtWage";
            this.txtWage.Size = new System.Drawing.Size(254, 35);
            this.txtWage.TabIndex = 1;
            this.txtWage.TextChanged += new System.EventHandler(this.txtWage_TextChanged);
            // 
            // workedHour
            // 
            this.workedHour.AutoSize = true;
            this.workedHour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.workedHour.Location = new System.Drawing.Point(709, 286);
            this.workedHour.Name = "workedHour";
            this.workedHour.Size = new System.Drawing.Size(155, 29);
            this.workedHour.TabIndex = 0;
            this.workedHour.Text = "Worked Hour";
            // 
            // txtWorkedHour
            // 
            this.txtWorkedHour.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtWorkedHour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWorkedHour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWorkedHour.Location = new System.Drawing.Point(714, 333);
            this.txtWorkedHour.Name = "txtWorkedHour";
            this.txtWorkedHour.Size = new System.Drawing.Size(254, 35);
            this.txtWorkedHour.TabIndex = 1;
            this.txtWorkedHour.TextChanged += new System.EventHandler(this.txtWorkedHour_TextChanged);
            // 
            // joinedDate
            // 
            this.joinedDate.AutoSize = true;
            this.joinedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.joinedDate.Location = new System.Drawing.Point(33, 418);
            this.joinedDate.Name = "joinedDate";
            this.joinedDate.Size = new System.Drawing.Size(142, 29);
            this.joinedDate.TabIndex = 0;
            this.joinedDate.Text = "Joined Date";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Location = new System.Drawing.Point(38, 471);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(254, 30);
            this.dateTimePicker.TabIndex = 2;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Red;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(701, 463);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(110, 50);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Green;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(858, 463);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(110, 50);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // comboBoxDepartment
            // 
            this.comboBoxDepartment.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.comboBoxDepartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDepartment.FormattingEnabled = true;
            this.comboBoxDepartment.Location = new System.Drawing.Point(38, 340);
            this.comboBoxDepartment.Name = "comboBoxDepartment";
            this.comboBoxDepartment.Size = new System.Drawing.Size(254, 33);
            this.comboBoxDepartment.TabIndex = 4;
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 541);
            this.Controls.Add(this.comboBoxDepartment);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.address);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.txtDesignation);
            this.Controls.Add(this.designation);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.email);
            this.Controls.Add(this.txtWorkedHour);
            this.Controls.Add(this.txtWage);
            this.Controls.Add(this.workedHour);
            this.Controls.Add(this.wage);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.joinedDate);
            this.Controls.Add(this.department);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.txtIdNo);
            this.Controls.Add(this.idNo);
            this.Name = "AddEmployee";
            this.Text = "AddEmployee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label idNo;
        private System.Windows.Forms.TextBox txtIdNo;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label designation;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.Label department;
        private System.Windows.Forms.Label wage;
        private System.Windows.Forms.TextBox txtWage;
        private System.Windows.Forms.Label workedHour;
        private System.Windows.Forms.TextBox txtWorkedHour;
        private System.Windows.Forms.Label joinedDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox comboBoxDepartment;
    }
}